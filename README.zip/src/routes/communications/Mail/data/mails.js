export default [
  {
    'id': '15453ba60d3baa5daaf',
    'from': {
      'name': 'Domnic Harris',
      'avatar': "https://via.placeholder.com/150",
      'email': 'domnicharris@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }, {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Fusce a libero pellentesque',
    'message': 'Maecenas sem arcu, scelerisque in odio vel, porttitor dignissim purus. Sed vehicula commodo porta. Etiam nec dictum mauris. Ut imperdiet maximus orci vitae ornare. Nullam et libero sit amet tellus ultricies rutrum et sit amet nisl. Pellentesque condimentum diam sed hendrerit facilisis. Suspendisse bibendum convallis quam, sit amet rutrum nisi pulvinar et. Nunc placerat, diam at scelerisque viverra, mi velit auctor nibh, at rhoncus erat ex vitae felis. Integer sed ante eget est rutrum ultrices ut non ipsum.',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [
      3,
      2
    ],
    'selected': false,
    'folder': 0
  },
  {
    'id': '15453a06c08fb021776',
    'from': {
      'name': 'Garry Sobars',
      'avatar': "https://via.placeholder.com/150",
      'email': 'danielleobrien@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Nullam id ex at augue pharetra vestibulum eget id mauris.',
    'message': 'Cras bibendum tortor tortor, eu luctus risus gravida ut. Suspendisse nisi tortor, consequat at pellentesque quis, dapibus vel risus. Praesent aliquam sit amet diam quis luctus. Nulla facilisi. Maecenas id molestie tortor. Nulla eget pretium nulla. Etiam consequat dictum velit, at egestas lacus laoreet ac. Ut facilisis massa vel mi fringilla, non blandit eros dictum. Integer in tellus vitae nisi tincidunt pulvinar. Maecenas ac ante ut felis feugiat ornare id a quam. Quisque feugiat ante quis ornare placerat.',
    'time': '4 Dec',
    'read': true,
    'starred': true,
    'important': false,
    'hasAttachments': false,
    'labels': [
      1,
      3
    ],
    'selected': false,
    'folder': 0
  },
  {
    'id': '1541ca7af66da284177',
    'from': {
      'name': 'Stella Brown',
      'avatar': '',
      'email': 'stellgrown@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Vivamus venenatis tempus ipsum, id finibus libero aliquet convallis.',
    'message': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce lorem diam, pulvinar id nisl non, ultrices maximus nibh. Suspendisse ut justo velit. Nullam ac ultrices risus, quis auctor orci. Vestibulum volutpat nisi et neque porta ullamcorper. Maecenas porttitor porta erat ac suscipit. Sed cursus leo ut elementum fringilla. Maecenas semper viverra erat, vel ullamcorper dui efficitur in. Vestibulum placerat imperdiet tellus, et tincidunt eros posuere eget. Proin sit amet facilisis libero. Nulla eget est ut erat aliquet rhoncus. Quisque ac urna vitae dui hendrerit sollicitudin vel id sem.  In eget ante sapien. Quisque consequat velit non ante finibus, vel placerat erat ultricies. Aliquam bibendum justo erat, ultrices vehicula dolor elementum a. Mauris eu nisl feugiat ligula molestie eleifend.\n Aliquam efficitur venenatis velit ac porta. Vivamus vitae pulvinar tellus. Donec odio enim, auctor eget nibh mattis, ultricies dignissim lacus. Phasellus non tincidunt dui. Nulla eu arcu lorem.  Donec non hendrerit augue, lobortis sollicitudin odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis sit amet euismod enim, eget vestibulum justo. Fusce a placerat lectus, eget feugiat purus. Cras risus ante, faucibus eget justo commodo, volutpat tempor ante. Donec sit amet leo venenatis, gravida quam sit amet, blandit dui. In quam ante, elementum ut faucibus nec, tristique vitae dui.  \n \n Praesent vel erat at enim placerat luctus vel ut ipsum. In congue tempor mi, non ornare lectus condimentum at. Aenean libero diam, finibus eget sapien et, tristique fermentum lorem.  ',
    'time': '3 Dec',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '154297167e781781745',
    'from': {
      'name': 'Steve Jonson',
      'avatar': '',
      'email': 'stevejonson@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Donec ut ante tristique, gravida justo vitae',
    'message': 'dictum at ligula vitae, posuere sagittis augue. Nam vitae eros quis felis consectetur egestas vitae vitae massa. Vestibulum tincidunt nisi neque, eu ullamcorper risus aliquet vel. Nunc ut lorem dapibus, interdum nulla vel, euismod elit. Fusce a mollis erat, non egestas dui. Fusce eu rutrum orci. Aliquam hendrerit metus sit amet interdum iaculis. Morbi eget nibh ut nibh convallis fermentum vitae ac mauris. Phasellus ligula purus, eleifend vel massa ut, interdum pulvinar sapien. Nullam a ex nec elit condimentum mattis. Nullam sit amet dictum neque, vel sagittis eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. ',
    'time': '3 Dec',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '15427f4c1b7f3953234',
    'from': {
      'name': 'Ira Shorter',
      'avatar': '',
      'email': 'irashorter@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Commits that need to be pushed lorem ipsum dolor sit amet',
    'message': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce lorem diam, pulvinar id nisl non, ultrices maximus nibh. Suspendisse ut justo velit. Nullam ac ultrices risus, quis auctor orci. Vestibulum volutpat nisi et neque porta ullamcorper. Maecenas porttitor porta erat ac suscipit. Sed cursus leo ut elementum fringilla. Maecenas semper viverra erat, vel ullamcorper dui efficitur in. Vestibulum placerat imperdiet tellus, et tincidunt eros posuere eget. Proin sit amet facilisis libero. Nulla eget est ut erat aliquet rhoncus. Quisque ac urna vitae dui hendrerit sollicitudin vel id sem.  In eget ante sapien. Quisque consequat velit non ante finibus, vel placerat erat ultricies. Aliquam bibendum justo erat, ultrices vehicula dolor elementum a. Mauris eu nisl feugiat ligula molestie eleifend.\n Aliquam efficitur venenatis velit ac porta. Vivamus vitae pulvinar tellus. Donec odio enim, auctor eget nibh mattis, ultricies dignissim lacus. Phasellus non tincidunt dui. Nulla eu arcu lorem.  Donec non hendrerit augue, lobortis sollicitudin odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis sit amet euismod enim, eget vestibulum justo. Fusce a placerat lectus, eget feugiat purus. Cras risus ante, faucibus eget justo commodo, volutpat tempor ante. Donec sit amet leo venenatis, gravida quam sit amet, blandit dui. In quam ante, elementum ut faucibus nec, tristique vitae dui.  \n \n Praesent vel erat at enim placerat luctus vel ut ipsum. In congue tempor mi, non ornare lectus condimentum at. Aenean libero diam, finibus eget sapien et, tristique fermentum lorem.  ',
    'time': '2 Dec',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 3
  },
  {
    'id': '15459251a6d6b397565',
    'from': {
      'name': 'Alex Dolgove',
      'avatar': "https://via.placeholder.com/150",
      'email': 'alexdolgove@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Ut tincidunt massa non elementum fermentum..',
    'message': 'Nullam vel ipsum eget odio viverra pellentesque. Nulla auctor eu felis eget vulputate. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque quam nisi, pulvinar vitae nulla sed, blandit auctor lacus. Vestibulum et semper lorem. Suspendisse interdum est neque, ut tempus eros ultricies et. Proin ultricies elit ac est egestas pharetra. Praesent id mollis enim. Suspendisse quis arcu nec lacus molestie pharetra sit amet in mauris.',
    'time': '2 Dec',
    'read': false,
    'starred': false,
    'important': true,
    'hasAttachments': true,
    'attachments': [
      {
        'type': 'image',
        'fileName': 'bike',
        'preview': "https://via.placeholder.com/500X333",
        'url': '',
        'size': '1.1Mb'
      },
      {
        'type': 'image',
        'fileName': 'burgers',
        'preview': "https://via.placeholder.com/500X333",
        'url': '',
        'size': '380kb'
      },
      {
        'type': 'image',
        'fileName': 'camera',
        'preview': "https://via.placeholder.com/600X400",
        'url': "https://via.placeholder.com/600X400",
        'size': '17Mb'
      }
    ],
    'labels': [
      1
    ],
    'selected': false,
    'folder': 0
  },
  {
    'id': '154588a0864d2881124',
    'from': {
      'name': 'Domnic Brown',
      'avatar':"https://via.placeholder.com/150",
      'email': 'domnicbrown@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Fusce eu rutrum orci. Aliquam hendrerit metus sit amet interdum ',
    'message': 'Phasellus ligula purus, eleifend vel massa ut, interdum pulvinar sapien. Nullam a ex nec elit condimentum mattis. Nullam sit amet dictum neque, vel sagittis eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas..',
    'time': '1 Dec',
    'read': false,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '154537435d5b32bf11a',
    'from': {
      'name': 'Brian Lara',
      'avatar': '',
      'email': 'brianlara@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Quisque felis nisi, iaculis at lacinia et.',
    'message': 'Aenean facilisis, lorem eget interdum tristique, velit odio tempus orci, sed molestie felis ipsum dignissim leo. Praesent volutpat convallis molestie. Praesent eu massa gravida, semper lacus id, blandit turpis. Nullam posuere sodales dignissim. Nunc commodo dui sit amet posuere lobortis. Aliquam placerat mi at felis laoreet, non aliquam odio varius. Nulla ultrices leo vel metus finibus, tempor feugiat velit mattis. Donec et commodo nisl, sit amet dignissim mi. Ut ullamcorper lacus sed magna pretium commodo. Sed dictum auctor sem vitae tincidunt. Morbi ut justo sit amet tortor tincidunt aliquet. Aenean at est in lorem pulvinar fermentum.',
    'time': '1 Dec',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '1544e43dcdae6ebf876',
    'from': {
      'name': 'Jeson Born',
      'avatar': "https://via.placeholder.com/150",
      'email': 'jesonborn@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'The standard Lorem Ipsum passage',
    'message': 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided.\n But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse painsAt vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. ',
    'time': '30 Nov',
    'read': true,
    'starred': false,
    'important': true,
    'hasAttachments': false,
    'labels': [
      2
    ],
    'selected': false,
    'folder': 0
  },
  {
    'id': '1543ee3a5b43e0f9f45',
    'from': {
      'name': 'Domnic White',
      'avatar': '',
      'email': 'domnicwhite@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Cras bibendum tortor tortor.',
    'message': 'Cras bibendum tortor tortor, eu luctus risus gravida ut. Suspendisse nisi tortor, consequat at pellentesque quis, dapibus vel risus. Praesent aliquam sit amet diam quis luctus. Nulla facilisi. Maecenas id molestie tortor. Nulla eget pretium nulla. Etiam consequat dictum velit, at egestas lacus laoreet ac. Ut facilisis massa vel mi fringilla, non blandit eros dictum. Integer in tellus vitae nisi tincidunt pulvinar. Maecenas ac ante ut felis feugiat ornare id a quam. Quisque feugiat ante quis ornare placerat.',
    'time': '30 Nov',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '1543cc4515df3146112',
    'from': {
      'name': 'Jimmy Jo',
      'avatar': "https://via.placeholder.com/150",
      'email': 'jimmy.jo@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Contrary to popular belief. ',
    'message': 'ontrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.\n This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32',
    'time': '29 Nov',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '154398a4770d7aaf9a2',
    'from': {
      'name': 'John Smith',
      'avatar':"https://via.placeholder.com/150",
      'email': 'johnsmith@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Ut elementum rhoncus nisl.',
    'message': ['Suspendisse congue ipsum tincidunt justo dictum, sit amet finibus lectus egestas. Proin fermentum nec risus vitae accumsan. Vivamus non ligula eu urna mattis feugiat. Pellentesque ex felis, commodo sed sem a, pharetra semper purus. Curabitur in quam rhoncus, blandit eros tempor, sodales metus. Pellentesque vel luctus ex. Quisque blandit nisl at tincidunt viverra. Phasellus elementum faucibus leo ac molestie.'],
    'time': '1 Dec',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '15438351f87dcd68567',
    'from': {
      'name': 'Jonny Brown',
      'avatar': '',
      'email': 'jonnnybrown@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Integer nec tempus eros.',
    'message': 'Vestibulum ornare orci hendrerit elit egestas, nec consectetur mi lobortis. Mauris porttitor dolor in neque aliquam, in sollicitudin enim consequat. Fusce pharetra venenatis fermentum.\n \n Maecenas semper nisi quis lectus dictum, vel fermentum purus malesuada. Nunc tincidunt sit amet nunc sit amet eleifend. Sed tellus risus, sagittis id magna in, commodo feugiat risus. Donec commodo pretium dolor non hendrerit. Nullam id leo et quam cursus vestibulum. Ut id aliquet diam, id varius libero. Ut et felis et est eleifend dignissim vitae condimentum ex. Ut a ullamcorper ante, ac laoreet erat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.',
    'time': '28 Nov',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [0],
    'selected': false,
    'folder': 0
  },
  {
    'id': '1542d75d929a603125',
    'from': {
      'name': 'Rahim Kadir',
      'avatar': '',
      'email': 'rahimkadir@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Praesent tortor odio, laoreet.',
    'message': 'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed id eros sit amet lorem viverra tincidunt eget id dolor. Morbi egestas bibendum ipsum at efficitur. Suspendisse at mauris justo. Curabitur elementum ante et lacus blandit, quis faucibus lorem pellentesque. Duis et auctor quam, sed lacinia ante. Nam placerat lacus eu mollis lobortis. Sed placerat, ipsum eu vestibulum gravida, magna sapien feugiat felis, non varius leo mauris vitae ligula. Suspendisse tincidunt nec enim eu porttitor.',
    'time': '27 Nov',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 0
  },
  {
    'id': '154204e45a59b168453',
    'from': {
      'name': 'Kadir',
      'avatar': "https://via.placeholder.com/150",
      'email': 'kadirm@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Many desktop publishing packages',
    'message': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce lorem diam, pulvinar id nisl non, ultrices maximus nibh. Suspendisse ut justo velit. Nullam ac ultrices risus, quis auctor orci. Vestibulum volutpat nisi et neque porta ullamcorper. Maecenas porttitor porta erat ac suscipit. Sed cursus leo ut elementum fringilla. Maecenas semper viverra erat, vel ullamcorper dui efficitur in. Vestibulum placerat imperdiet tellus, et tincidunt eros posuere eget. Proin sit amet facilisis libero. Nulla eget est ut erat aliquet rhoncus. Quisque ac urna vitae dui hendrerit sollicitudin vel id sem.  In eget ante sapien. Quisque consequat velit non ante finibus, vel placerat erat ultricies. Aliquam bibendum justo erat, ultrices vehicula dolor elementum a.  \n \n Mauris eu nisl feugiat ligula molestie eleifend. Aliquam efficitur venenatis velit ac porta. Vivamus vitae pulvinar tellus. Donec odio enim, auctor eget nibh mattis, ultricies dignissim lacus.\n Phasellus non tincidunt dui. Nulla eu arcu lorem.  Donec non hendrerit augue, lobortis sollicitudin odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis sit amet euismod enim, eget vestibulum justo. Fusce a placerat lectus, eget feugiat purus. Cras risus ante, faucibus eget justo commodo, volutpat tempor ante. Donec sit amet leo venenatis, gravida quam sit amet, blandit dui. In quam ante, elementum ut faucibus nec, tristique vitae dui. Praesent vel erat at enim placerat luctus vel ut ipsum. \n \n In congue tempor mi, non ornare lectus condimentum at. Aenean libero diam, finibus eget sapien et, tristique fermentum lorem.  ',
    'time': '26 Nov',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [0],
    'selected': false,
    'folder': 3
  },
  {
    'id': '1541dd1e05dfc439216',
    'from': {
      'name': 'Stella Johnson',
      'avatar': "https://via.placeholder.com/150",
      'email': 'stella-johnson@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Section 1.10.32 of "de',
    'message': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce lorem diam, pulvinar id nisl non, ultrices maximus nibh. Suspendisse ut justo velit. Nullam ac ultrices risus, quis auctor orci. Vestibulum volutpat nisi et neque porta ullamcorper. Maecenas porttitor porta erat ac suscipit. Sed cursus leo ut elementum fringilla. \n \n Maecenas semper viverra erat, vel ullamcorper dui efficitur in. Vestibulum placerat imperdiet tellus, et tincidunt eros posuere eget. Proin sit amet facilisis libero. Nulla eget est ut erat aliquet rhoncus. Quisque ac urna vitae dui hendrerit sollicitudin vel id sem.  In eget ante sapien. Quisque consequat velit non ante finibus, vel placerat erat ultricies. Aliquam bibendum justo erat, ultrices vehicula dolor elementum a. Mauris eu nisl feugiat ligula molestie eleifend. Aliquam efficitur venenatis velit ac porta. Vivamus vitae pulvinar tellus. Donec odio enim, auctor eget nibh mattis, ultricies dignissim lacus.\n Phasellus non tincidunt dui. Nulla eu arcu lorem.  Donec non hendrerit augue, lobortis sollicitudin odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis sit amet euismod enim, eget vestibulum justo. Fusce a placerat lectus, eget feugiat purus. Cras risus ante, faucibus eget justo commodo, volutpat tempor ante. Donec sit amet leo venenatis, gravida quam sit amet, blandit dui. In quam ante, elementum ut faucibus nec, tristique vitae dui. Praesent vel erat at enim placerat luctus vel ut ipsum. In congue tempor mi, non ornare lectus condimentum at. Aenean libero diam, finibus eget sapien et, tristique fermentum lorem.  ',
    'time': '25 Nov',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 3
  },
  {
    'id': '1541dd1e05dfc439217',
    'from': {
      'name': 'Steve Smith',
      'avatar': "https://via.placeholder.com/150",
      'email': 'stevesmith@example.com'
    },
    'to': [
      {
        'name': 'me',
        'email': 'robert.johnson@example.com'
      }
    ],
    'subject': 'Integer nec tempus eros.',
    'message': 'Curabitur id rutrum ex. Morbi tempus libero eget mauris ultricies venenatis. Curabitur eget pellentesque lorem. Morbi in tempor sem, vel posuere odio. Vivamus sit amet efficitur tortor. Fusce in tortor non lorem blandit eleifend quis eu risus. Donec lobortis ex justo, sed suscipit dolor posuere eget.',
    'time': '24 Nov',
    'read': true,
    'starred': false,
    'important': false,
    'hasAttachments': false,
    'labels': [],
    'selected': false,
    'folder': 3
  }
];
