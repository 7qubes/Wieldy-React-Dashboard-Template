export default [
  {
    'id': 0,
    'handle': 'note',
    'title': 'PayPal',
    'color': 'purple'
  },
  {
    'id': 1,
    'handle': 'paypal',
    'title': 'Upwork',
    'color': 'amber'
  },
  {
    'id': 2,
    'handle': 'invoice',
    'title': 'In-house',
    'color': 'green'
  },
  {
    'id': 3,
    'handle': 'amazon',
    'title': 'Clients',
    'color': 'light-blue'
  }
];
