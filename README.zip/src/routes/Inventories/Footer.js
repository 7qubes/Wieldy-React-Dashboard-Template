import React from "react";

export default ({children}) =>
  <div className="gx-algolia-footer">
    {children}
  </div>
