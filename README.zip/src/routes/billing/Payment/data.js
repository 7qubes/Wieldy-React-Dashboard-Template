export default [
  {
    'id': 1457690401,
    'name': 'All State',
    'number': "12345678931",
    'selected': false,
    'order': false,
    'frequently': true,
    'last': true,
    'utils': false,
    'employee': false
  }, {
    'id': 1457690400,
    'name': 'HomeDepot',
    'number': "12345678931",
    'selected': false,
    'order': false,
    'frequently': false,
    'last': false,
    'utils': true,
    'employee': false
  }, {
    'id': 1457690401,
    'name': 'Verizon',
    'number': "12345678931",
    'selected': false,
    'order': false,
    'frequently': false,
    'last': true,
    'utils': false,
    'employee': false
  },
  {
    'id': 1457690402,
    'name': 'ComEd',
    'number': "12345678931",
    'selected': false,
    'order': false,
    'frequently': false,
    'last': false,
    'utils': false,
    'employee': true
  }
]
