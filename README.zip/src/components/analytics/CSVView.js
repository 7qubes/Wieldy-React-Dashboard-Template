import React from 'react';
import { useCSVStore } from '../../mobx/csvContext';
import { Table, Tag, Space } from 'antd'

export const CSVView = () => {
    const csvStore = useCSVStore();

    return (
        <div>
            {
                csvStore.getCSVData().map( item => {
                    console.log(item);
                    return (
                      //  <p>{item.split(';')}</p>
                      <p>Hello</p>
                    )
                })
            } 
        </div>
    )
}