module.exports = {
  footerText: 'Copyright - 7QUBES LLC © 2017-2020',
}
